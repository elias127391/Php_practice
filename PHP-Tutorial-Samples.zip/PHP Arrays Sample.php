<?php
// Example 1 - Indexed arrays -----------------------------------------
$names = array("Fabio", "Klevi", "John");
echo "My friends are " . $names[0] . ", " . $names[1] . " and " . $names[2];

echo "<br><br>";

// LOOPING thorugh indexed arrays
$names = array("Fabio", "Klevi", "John");
$arrayLength = count($names);

for($i = 0; $i < $arrayLength; $i++) {
    echo $names[$i];
    echo "<br>";
}
echo "<br><br>";

// Example 2 - Associative arrays -----------------------------------------
$namesAge = array("Fabio"=>"20", "Klevi"=>"16", "John"=>"43");
echo "Fabio's age is " . $namesAge['Fabio'] . " years old.";

echo "<br><br>";

// LOOPING thorugh associative arrays
$namesAge = array("Fabio"=>"20", "Klevi"=>"16", "John"=>"43");

foreach($namesAge as $i => $value) {
    echo "Key = " . $i . ", Value = " . $value;
    echo "<br>";
}
?>