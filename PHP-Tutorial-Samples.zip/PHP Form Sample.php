<h2>PHP Sample Form</h2>
<form method="POST" action="wcg.php">
    <p><input type="text" name="name" placeholder="Name"></p>
    <p><input type="email" name="email" placeholder="E-Mail"></p>
    <p><input type="number" name="age" placeholder="Age"></p>
    <input type="radio" name="gender" value="Male"> Male
    <input type="radio" name="gender" value="Female"> Female

    <p><input type="submit" name="submit" value="Submit"></p>
</form>

<h2>Input was:</h2>


<style type="text/css">

    input[type="text"], input[type="email"], input[type="number"] {
        height: 2.5em;
        width: 20em;
        padding-left: 1em;
    }
    input[type="submit"] {
        width: 20em;
        height: 2.5em;
    }
    * {
        font-family: "Roboto";
    }
</style>

<?php
if (isset($_POST["name"]) && !empty($_POST["name"])) {
    $name = $_POST["name"];
    if (!preg_match("/^[a-zA-Z ]*$/",$name))
    echo "Name: Only letters and whitespace allowed <br>";
    else
    echo "Name: ".$_POST["name"]."<br>";
}
if (isset($_POST["email"]) && !empty($_POST["email"])) {
    echo "E-Mail: ".$_POST["email"]."<br>";
}
if (isset($_POST["age"]) && !empty($_POST["age"])) {
    echo "Age: ".$_POST["age"]."<br>";
}
if (isset($_POST["gender"]) && !empty($_POST["gender"])) {
    echo "Gender: ".$_POST["gender"];
}
?>