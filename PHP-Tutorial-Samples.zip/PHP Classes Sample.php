<?php

// COMMENT CODE BLOCKS AND LEAVE ONLY ONE TO SEE THE RESULTS

// Example 1 - Defining a class ----------------------
class Vehicle {
    var $brand;       // just a declared undefined variable
    var $speed = 80;  // a declared and defined variable

    function setSpeed($speedValue) {  // a function to change speed
      $this->speed = $speedValue;     // this will replace speed with our value
    }

    function setBrand($brandName) {   // a function to change brand
        $this->brand = $brandName;    // this will set a brand name
    }

    function printDetails(){          // a function to print details
        echo "Vehicle brand is: ".$this->brand;
        echo "<br>";
        echo "Vehicle speed is: ".$this->speed;
    }
  }

  $myCar = new Vehicle;       // an instance of our Vehicle class (an object)
  $myCar->setBrand("Audi");   // calling the function setBrand to define a brand
  $myCar->setSpeed(120);      // calling the function setSpeed to change speed
  $myCar->printDetails();     // calling the printDetails function to see details




// Example 2 - A class with a constructor ------------
class Vehicle {
  function __construct ($brandName, $speedValue) {
    $this->brand = $brandName;  // initialize brand
    $this->speed = $speedValue; // initialize speed
    }
      function printDetails(){
          echo "Vehicle brand is: ".$this->brand;
          echo "<br>";
          echo "Vehicle speed is: ".$this->speed;
          echo "<br><br>";
      }
  }

    $car1 = new Vehicle("Toyota", 130);
    $car2 = new Vehicle ("Ferrari", 450);

    $car1->printDetails();
    $car2->printDetails();
?>