<footer>
    <p>All Rights Reserved. Do not reproduce this page.</p>
</footer>