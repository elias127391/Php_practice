<header>
<nav>
    <ul>
        <li><a href="#">Home</a></li>
        <li><a href="#">Profile</a></li>
        <li><a href="#">About</a></li>
        <li><a href="#">Contact</a></li>
    </ul>
</nav>
</header>

<style type="text/css">
    ul, li {
        list-style-type: none;
        display: inline-block;
        margin-right: 1em;
        padding: 0;
    }
</style>