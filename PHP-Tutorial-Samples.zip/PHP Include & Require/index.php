<?php require 'header.php'; ?>
<body>
    <h2>Main Content Goes Here</h2>
</body>

<style type="text/css">
    * {
        font-family: "Roboto";
    }
</style>
<?php include 'footer.php' ?>