
<?php

// UNCOMMENT EACH BLOCK OF CODE TO SEE THE RESULTS

$age = 18;

if ($age < 20) {
  echo "You are a teenager";
}

// ---------------------------------

// $age = 25;

// if ($age < 20) {
//   echo "You are a teenager";
// }
// else {
//   echo "You are an adult";
// }

// ---------------------------------

// $age = 3;
// if ($age < 10) {
// echo "You are a kid";
// }
// elseif ($age > 10 && $age < 20) {
// echo "You are a teenager";
// }
// else {
// echo "You are an adult";
// }
?>