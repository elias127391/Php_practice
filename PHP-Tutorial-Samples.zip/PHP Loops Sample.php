<?php

// UNCOMMENT ONE BY ONE THE BLOCKS OF CODE BELOW

for ($i=0; $i < 5; $i++) {
    echo "This is loop number $i <br>";
}

// $i=0;
// while ($i < 5) {
//   echo "This is loop number $i <br>";
//   $i++;
// }

// $i = 0;
// do {
//     $i++;
//     echo "This is loop number $i <br>";
// }
// while ($i < 5);
?>