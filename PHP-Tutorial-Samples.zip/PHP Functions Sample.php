<?php

// Example 1 -----------------------------------------
function showGreeting() { // function definition
  echo "Hello Chloe!";    // what this function does
}

showGreeting(); // function call

echo "<br><br>";

// Example 2 -----------------------------------------
function greetPerson($name) { // function definition with arguments
  echo "Hi there, ".$name;    // what this function does
}

greetPerson("Fabio"); // function call
echo "<br>";
greetPerson("Michael");

echo "<br><br>";

// Example 3 -----------------------------------------
function personProfile($name, $city, $job) { // function definition with arguments
  echo "This person is ".$name." from ".$city.".";
  echo "<br>";
  echo "His/Her job is ".$job.".";
}

personProfile("Fabio", "Tirana", "Web Dev");
echo "<br>";
personProfile("Michael", "Athens", "Graphic Designer");
echo "<br>";
personProfile("Xena", "London", "Tailor");

echo "<br><br>";

// Example 4 -----------------------------------------
function difference($a, $b) { // function definition with arguments
  $c = $a - $b;
  return $c;
}

echo "The difference of the given numbers is: ".difference(8, 3);
?>